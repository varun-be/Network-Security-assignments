#Reference: http://people.csail.mit.edu/hubert/pyaudio/


import pyaudio
import wave
#number of frames to which signals are split
c = 1024
f = pyaudio.paInt16
channel = 2
#r is the rate or number of frames per second
r = 44100
file_path = 'audio.wav'
w = wave.open(file_path, 'wb')
w.setnchannels(channel)
p = pyaudio.PyAudio()
stream = p.open(format=f,channels=channel,rate=r,input=True,frames_per_buffer=c)
print("Start recording")
frames = []
try:
	while True:
		data = stream.read(c)
		frames.append(data)
except KeyboardInterrupt:
	print("Done recording")
sample_width = p.get_sample_size(f)
stream.stop_stream()
stream.close()
p.terminate()
w.setsampwidth(sample_width)
w.setframerate(r)
w.writeframes(b''.join(frames))
w.close()
	