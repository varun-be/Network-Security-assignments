
import socket

soc = socket.socket()
soc.connect(('localhost',8080))

with soc,open("receivedfile.avi",'wb') as file:
	while True:
		recvfile1 = soc.recv(4096)
		if not recvfile1: break
		file.write(recvfile1)
	file.close()

