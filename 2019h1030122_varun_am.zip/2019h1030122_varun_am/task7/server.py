import hashlib
import socket
dictionary = {}
host = "127.0.0.1"
port = 5000  
server_socket = socket.socket() 
server_socket.bind((host, port)) 
server_socket.listen(2)
conn, address = server_socket.accept()
f = open("output.txt", "w")
def server():

    
      

    u = conn.recv(8).decode()    
    f.write(u)
    print(u, end = "")
    
   

    


if __name__ == '__main__':
    print("keys being stored in output.txt")

    while True:
        try:
            server()
        except Exception as e:
            print(e)
            break


f.close()
conn.close()  
server_socket.close()
    
