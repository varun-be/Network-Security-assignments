#This code takes images stored in dogimg folder and creates a video out of it
import cv2
import os

list = os.listdir("dogimg")
#print(list)
image_list = []

dim = 960,720

for file in list:
	#Get path of the folder that has the images
	path = str("dogimg/"+file)
	image = cv2.imread(path)
	#opencv requires the dimensions of the images to be same so resize images to same dimensions
	image = cv2.resize(image, dim, fx = 720, fy = 960)
	image_list.append(image)

result = cv2.VideoWriter('video_of_images.avi', cv2.VideoWriter_fourcc(*'DIVX'),1,dim)
print("The video is saved in the same folder as video_of_images.avi")
print("IMPORTANT: Please play the video with VLC media player, it is not tested with other players")


for i in range(0,len(image_list)):
	result.write(image_list[i])
cv2.destroyAllWindows()
result.release()
