h = open("video_with_spyware.avi","rb")
#h_val = []
#res = []
h_bytes = str(h.read())

spl_word = '###'
res = h_bytes.partition(spl_word)[2]

#print(res)
#res1 = str.encode(res)

z = open("extract_keylogger.py","w")
res2 = res.replace("\\n","\n")
res2 = res2.replace("'"," ")
#print(res2)
z.write(res2)
