1. Please run all the video files that are created using VLC, I have not tested with other media players
2. While running, please navigate into appropriate folders, for example run task3 inside the folder named Task3
3. Certain tasks take output of previous tasks as their input. I have already placed these outputs in the necessary folders
	You may delete these files, and copy the previous task output and run it in case you want to test the code implementation
	
4. Please install following packages

sudo apt-get install portaudio19-dev python-pyaudio
pip3 install PyAudio
pip3 install pynput  (For getting Keyboard input for keylogger)
 


##########################################################################################################################################################################################################
TASK1:
 Note that here client should start the connection. so run client first then run server

Run as : python3 client.py
		 python3 server.py





##########################################################################################################################################################################################################
TASK2: 

path:		/2019h1030122_varun_am/task2

Run as:		"python3 webcam.py"
output:		Saved as output.avi in same directory where it is ru







##########################################################################################################################################################################################################
TASK3:

path:		/2019h1030122_varun_am/task2

Run as:		"python3 audio.py"
output:		saved as audio.wav in same directory where it is run	





##########################################################################################################################################################################################################
TASK4:

Working:	Takes images stored in dogimg file, converts to video
			Also seperately, a keylogger script is also there as keylogger.py

1:Run as:		"python3 imagestovideo.py"
  output:		saved as video_of_images.avi in the same directory 

2:Run as: 		"python3 keylogger.py"
  output:		saved in output.txt





##########################################################################################################################################################################################################
TASK5:			[Requires video_of_images.avi and keylogger from task4]

Run as: 		python3 stego.py

Working:		It takes video_of_images.avi and  client_keylogger.py(modified keylogger from task 4) from task4 as input and gives video_with_spyware.avi as output



##########################################################################################################################################################################################################
TASK6: 			[Requires video_with_spyware.avi as input from task5]

Run as: 		python3 get_back_script_from_video.py
				
Working:		The client takes video_with_spyware.avi from Task5 as input,extracts the spyware  and and gives extract_keylogger.py as output
				








##########################################################################################################################################################################################################
TASK7:			[Requires extract_keylogger.py from Task6]


Run as:			"python3 server.py" in first terminal
				"python3 client.py" in second terminal
				
				Everything typed in clients terminal will be displayed in server as well as saved in output.txt in servers directory
				Here the client is running the hidden spyware that it extracted in Task6







##########################################################################################################################################################################################################


